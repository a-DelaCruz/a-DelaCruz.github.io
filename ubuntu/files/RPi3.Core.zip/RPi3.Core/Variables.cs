namespace RPi3.Core
{
    internal unsafe static class Variables
    {
        internal static volatile uint* bcm2835_gpio = (uint*)Cons_State.MAP_FAILED;
        internal static volatile uint* bcm2835_pwm = (uint*)Cons_State.MAP_FAILED;
        internal static volatile uint* bcm2835_clk = (uint*)Cons_State.MAP_FAILED;
        internal static volatile uint* bcm2835_pads = (uint*)Cons_State.MAP_FAILED;
        internal static volatile uint* bcm2835_spi0 = (uint*)Cons_State.MAP_FAILED;
        internal static volatile uint* bcm2835_bsc0 = (uint*)Cons_State.MAP_FAILED;
        internal static volatile uint* bcm2835_bsc1 = (uint*)Cons_State.MAP_FAILED;
        internal static volatile uint* bcm2835_st = (uint*)Cons_State.MAP_FAILED;

        // Physical address and size of the peripherals block
        // May be overridden on RPi2
        internal static uint* bcm2835_peripherals_base = (uint*)Cons.BCM2835_PERI_BASE;
        internal static uint bcm2835_peripherals_size = Cons.BCM2835_PERI_SIZE;

        // Virtual memory address of the mapped peripherals block
        internal static uint* bcm2835_peripherals = (uint*)Cons_State.MAP_FAILED;

        // I2C The time needed to transmit one byte. In microseconds.
        internal static int i2c_byte_wait_us = 0;
    }
}
 