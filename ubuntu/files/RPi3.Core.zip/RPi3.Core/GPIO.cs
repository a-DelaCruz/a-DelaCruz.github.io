using System;
using System.IO;
using System.Threading;
using static RPi3.Core.Enums;
using static RPi3.Core.Interop.Enums;

namespace RPi3.Core
{
    public unsafe class GPIO
    {
        #region Library Initialization and Closing
            // Initialise this library.
            public static int bcm2835_init()
            {
                int memfd;
                int ok_value;
                byte[] buf = new byte[4];

                // Figure out the base and size of the peripheral address block using the device-tree.
                if (File.Exists(Cons.BMC2835_RPI2_DT_FILENAME))
                {
                    using (FileStream dtFileContent = File.OpenRead(Cons.BMC2835_RPI2_DT_FILENAME))
                    {
                        dtFileContent.Seek(Cons.BMC2835_RPI2_DT_PERI_BASE_ADDRESS_OFFSET, SeekOrigin.Begin);
                        if (dtFileContent.Read(buf, 0, buf.Length) == buf.Length)
                            Variables.bcm2835_peripherals_base = (uint*)(buf[0] << 24 | buf[1] << 16 | buf[2] << 8 | buf[3] << 0);

                        dtFileContent.Seek(Cons.BMC2835_RPI2_DT_PERI_SIZE_OFFSET, SeekOrigin.Begin);
                        if (dtFileContent.Read(buf, 0, buf.Length) == buf.Length)
                            Variables.bcm2835_peripherals_size = (uint)(buf[0] << 24 | buf[1] << 16 | buf[2] << 8 | buf[3] << 0);
                    }
                }
                ok_value = 0;

                // Now get ready to map the peripherals block. If we are not root, try for the new /dev/gpiomem interface and accept
                //the fact that we can only access GPIO else try for the /dev/mem interface and get access to everything
                if (Interop.Interop.geteuid() == 0)
                {   // Open the master /dev/mem device
                    if ((memfd = Interop.Interop.open("/dev/mem", OpenFlags.O_RDWR | OpenFlags.O_SYNC)) < 0)
                        Console.WriteLine("bcm2835_init: Unable to open /dev/mem");

                    // Base of the peripherals block is mapped to VM
                    Variables.bcm2835_peripherals = (uint*)Mmap.mapmem(Variables.bcm2835_peripherals_size, memfd, (uint)Variables.bcm2835_peripherals_base);
                    Interop.Interop.close(memfd);
                    if (Variables.bcm2835_peripherals == (uint*)Cons_State.MAP_FAILED)
                        Console.WriteLine("peripherals: {0}", (uint)Variables.bcm2835_peripherals);
                    // Now compute the base addresses of various peripherals, 
                    // which are at fixed offsets within the mapped peripherals block
                    // Caution: bcm2835_peripherals is uint32_t*, so divide offsets by 4
                    Variables.bcm2835_gpio = Variables.bcm2835_peripherals + Cons.BCM2835_GPIO_BASE / 4;
                    Variables.bcm2835_pwm = Variables.bcm2835_peripherals + Cons.BCM2835_GPIO_PWM / 4;
                    Variables.bcm2835_clk = Variables.bcm2835_peripherals + Cons.BCM2835_CLOCK_BASE / 4;
                    Variables.bcm2835_pads = Variables.bcm2835_peripherals + Cons.BCM2835_GPIO_PADS / 4;
                    Variables.bcm2835_spi0 = Variables.bcm2835_peripherals + Cons.BCM2835_SPI0_BASE / 4;
                    Variables.bcm2835_bsc0 = Variables.bcm2835_peripherals + Cons.BCM2835_BSC0_BASE / 4; // I2C 
                    Variables.bcm2835_bsc1 = Variables.bcm2835_peripherals + Cons.BCM2835_BSC1_BASE / 4; // I2C 
                    Variables.bcm2835_st = Variables.bcm2835_peripherals + Cons.BCM2835_ST_BASE / 4;

                    ok_value = 1;
                }
                else
                {   // Not root, try /dev/gpiomem
                    if ((memfd = Interop.Interop.open("/dev/gpiomem", OpenFlags.O_RDWR | OpenFlags.O_SYNC)) < 0)
                        Console.WriteLine("bcm2835_init: Unable to open /dev/gpiomem");

                    /* Base of the peripherals block is mapped to VM */
                    Variables.bcm2835_peripherals_base = (uint*)0;
                    Variables.bcm2835_peripherals = (uint*)Mmap.mapmem(Variables.bcm2835_peripherals_size, memfd, (uint)Variables.bcm2835_peripherals_base);
                    Interop.Interop.close(memfd);
                    if (Variables.bcm2835_peripherals == (uint*)Cons_State.MAP_FAILED)
                        Console.WriteLine("peripherals: {0}", (IntPtr)Variables.bcm2835_peripherals);

                    ok_value = 1;
                }


                if (ok_value == 0)
                    bcm2835_close();

                return ok_value;
            }

            public static int bcm2835_close()
            {
                Mmap.unmapmem(ref Variables.bcm2835_peripherals, Variables.bcm2835_peripherals_size);
                Variables.bcm2835_peripherals = (uint*)Cons_State.MAP_FAILED;
                Variables.bcm2835_gpio = (uint*)Cons_State.MAP_FAILED;
                Variables.bcm2835_pwm = (uint*)Cons_State.MAP_FAILED;
                Variables.bcm2835_clk = (uint*)Cons_State.MAP_FAILED;
                Variables.bcm2835_pads = (uint*)Cons_State.MAP_FAILED;
                Variables.bcm2835_spi0 = (uint*)Cons_State.MAP_FAILED;
                Variables.bcm2835_bsc0 = (uint*)Cons_State.MAP_FAILED;
                Variables.bcm2835_bsc1 = (uint*)Cons_State.MAP_FAILED;
                Variables.bcm2835_st = (uint*)Cons_State.MAP_FAILED;

                return 1;
            }
        #endregion

        #region Time and Delays
            private static long st_read()
            {
                uint* paddr;
                uint hi, lo;
                ulong st;
                paddr = Variables.bcm2835_st + Cons.BCM2835_ST_CHI / 4;
                hi = peri_read(paddr);

                paddr = Variables.bcm2835_st + Cons.BCM2835_ST_CLO / 4;
                lo = peri_read(paddr);

                paddr = Variables.bcm2835_st + Cons.BCM2835_ST_CHI / 4;
                st = peri_read(paddr);

                /* Test for overflow */
                if (st == hi)
                {
                    st <<= 32;
                    st += lo;
                }
                else
                {
                    st <<= 32;
                    paddr = Variables.bcm2835_st + Cons.BCM2835_ST_CLO / 4;
                    st += peri_read(paddr);
                }

                return (long)st;
            }

            // Some convenient arduino-like functions milliseconds
            public static void delay(uint millis)
            {
                var t1 = new timespec();
                var t2 = new timespec();

                t1.tv_sec = (IntPtr)(millis / 1000);
                t1.tv_nsec = (IntPtr)((long)(millis % 1000) * 1000000);
                Interop.Interop.nanosleep(ref t1, ref t2);
            }

            // Delays for the specified number of microseconds with offset
            private static void st_delay(long offset_micros, long micros)
            {
                long compare = offset_micros + micros;

                while (st_read() < compare)
                    ;
            }

            /* microseconds */
            public static void delayMicroseconds(long micros)
            {
                var t1 = new timespec();
                var t2 = new timespec();
                long start;


                /* Calling nanosleep() takes at least 100-200 us, so use it for
                // long waits and use a busy wait on the System Timer for the rest.
                */
                start = st_read();

                if (micros > 450)
                {
                    t1.tv_sec = (IntPtr)0;
                    t1.tv_nsec = (IntPtr)(1000 * (long)(micros - 200));
                    Interop.Interop.nanosleep(ref t1, ref t2);
                }

                st_delay(start, micros);
            }
        #endregion

        #region Peripherals
            // Read with memory barriers from peripheral
            internal static uint peri_read(uint* paddr)
            {
                uint ret;

                Thread.MemoryBarrier();
                ret = *paddr;
                Thread.MemoryBarrier();
                return ret;

            }

            // read from peripheral without the read barrier
            // This can only be used if more reads to THE SAME peripheral
            // will follow.  The sequence must terminate with memory barrier
            // before any read or write to another peripheral can occur.
            // The MB can be explicit, or one of the barrier read/write calls.
            public static uint peri_read_nb(uint* paddr)
            {
                return *paddr;
            }

            // Write with memory barriers to peripheral
            internal static void peri_write(uint* paddr, uint value)
            {
                Interop.Interop.sync();

                Thread.MemoryBarrier();
                *paddr = value;
                Thread.MemoryBarrier();

            }

            // write to peripheral without the write barrier
            public static void peri_write_nb(uint* paddr, uint value)
            {
                *paddr = value;
            }

            // Set/clear only the bits in value covered by the mask. This is not atomic - can be interrupted.
            internal static void peri_set_bits(uint* paddr, uint value, uint mask)
            {

                uint v = peri_read(paddr);
                v = (v & ~mask) | (value & mask);
                peri_write(paddr, v);
            }

        #endregion

        #region GPIO
            //Function select
            // pin is a BCM2835 GPIO pin number NOT RPi pin number
            //      There are 6 control registers, each control the functions of a block
            //      of 10 pins.
            //      Each control register has 10 sets of 3 bits per GPIO pin:
            //
            //      000 = GPIO Pin X is an input
            //      001 = GPIO Pin X is an output
            //      100 = GPIO Pin X takes alternate function 0
            //      101 = GPIO Pin X takes alternate function 1
            //      110 = GPIO Pin X takes alternate function 2
            //      111 = GPIO Pin X takes alternate function 3
            //      011 = GPIO Pin X takes alternate function 4
            //      010 = GPIO Pin X takes alternate function 5
            //
            // So the 3 bits for port X are:
            //      X / 10 + ((X % 10) * 3)
            public static void gpio_set_fsel(RPiGPIOPin pin, FSelect mode)
            {
                /* Function selects are 10 pins per 32 bit word, 3 bits per pin */
                uint* paddr = Variables.bcm2835_gpio + Cons.BCM2835_GPFSEL0 / 4 + ((byte)pin / 10);
                byte shift = (byte)(((byte)pin % 10) * 3);
                uint mask = (uint)FSelect.MASK << shift;
                uint value = (uint)((byte)mode << shift);
                peri_set_bits(paddr, value, mask);
            }

            // Read pin function state
            public static sbyte gpio_read_fsel(RPiGPIOPin pin)
            {
                uint* paddr = Variables.bcm2835_gpio + Cons.BCM2835_GPFSEL0 / 4 + ((byte)pin / 10);
                byte shift = (byte)(((byte)pin % 10) * 3);
                uint value = peri_read(paddr);
                return Convert.ToSByte(value >> shift);
            }

            // Set output pin 
            private static void gpio_set(RPiGPIOPin pin)
            {
                uint* paddr = Variables.bcm2835_gpio + Cons.BCM2835_GPSET0 / 4 + (byte)pin / 32;
                byte shift = (byte)((byte)pin % 32);
                peri_write(paddr, (uint)1 << shift);
            }

            // Clear output pin 
            private static void gpio_clr(RPiGPIOPin pin)
            {
                uint* paddr = Variables.bcm2835_gpio + Cons.BCM2835_GPCLR0 / 4 + (byte)pin / 32;
                byte shift = (byte)((byte)pin % 32);
                peri_write(paddr, (uint)1 << shift);
            }

            // Read input pin 
            public static byte gpio_lev(RPiGPIOPin pin)
            {
                uint* paddr = Variables.bcm2835_gpio + Cons.BCM2835_GPLEV0 / 4 + (byte)pin / 32;
                byte shift = (byte)((byte)pin % 32);
                uint value = peri_read(paddr);
                return (value & (1 << shift)) != 0 ? Cons_State.HIGH : Cons_State.LOW;
            }

            // Set the state of an output
            public static void gpio_write(RPiGPIOPin pin, byte on)
            {
                if (on == Cons_State.HIGH)
                    gpio_set(pin);
                else
                    gpio_clr(pin);
            }

            // Set pullup/down 
            private static void gpio_pud(PUDControl pud)
            {
                uint* paddr = Variables.bcm2835_gpio + Cons.BCM2835_GPPUD / 4;
                peri_write(paddr, (byte)pud);
            }

            // Pullup/down clock
            // Clocks the value of pud into the GPIO pin
            private static void gpio_pudclk(RPiGPIOPin pin, bool on)
            {
                uint* paddr = Variables.bcm2835_gpio + Cons.BCM2835_GPPUDCLK0 / 4 + (byte)pin / 32;
                byte shift = (byte)((byte)pin % 32);
                peri_write(paddr, (uint)(on ? 1 : 0) << shift);
            }

            // Set the pullup/down resistor for a pin
            //
            // The GPIO Pull-up/down Clock Registers control the actuation of internal pull-downs on
            // the respective GPIO pins. These registers must be used in conjunction with the GPPUD
            // register to effect GPIO Pull-up/down changes. The following sequence of events is
            // required:
            // 1. Write to GPPUD to set the required control signal (i.e. Pull-up or Pull-Down or neither
            // to remove the current Pull-up/down)
            // 2. Wait 150 cycles ? this provides the required set-up time for the control signal
            // 3. Write to GPPUDCLK0/1 to clock the control signal into the GPIO pads you wish to
            // modify ? NOTE only the pads which receive a clock will be modified, all others will
            // retain their previous state.
            // 4. Wait 150 cycles ? this provides the required hold time for the control signal
            // 5. Write to GPPUD to remove the control signal
            // 6. Write to GPPUDCLK0/1 to remove the clock
            //
            // RPi has P1-03 and P1-05 with 1k8 pullup resistor
            public static void gpio_set_pud(RPiGPIOPin pin, PUDControl pud)
            {
                gpio_pud(pud);
                delayMicroseconds(10);
                gpio_pudclk(pin, true);
                delayMicroseconds(10);
                gpio_pud(PUDControl.GPIO_PUD_OFF);
                gpio_pudclk(pin, false);
            }
        #endregion

        public unsafe static class I2C
        {
            public static int i2c_begin()
            {
                ushort cdiv;

                if (Variables.bcm2835_bsc0 == (uint*)Cons_State.MAP_FAILED || Variables.bcm2835_bsc1 == (uint*)Cons_State.MAP_FAILED)
                    return 0; // bcm2835_init() failed, or not root

                uint* paddr = Variables.bcm2835_bsc1 + Cons.BCM2835_BSC_DIV / 4;
                // Set the I2C/BSC1 pins to the Alt 0 function to enable I2C access on them
                gpio_set_fsel(Enums.RPiGPIOPin.GPIO_P1_03, Enums.FSelect.ALT0); /* SDA */
                gpio_set_fsel(Enums.RPiGPIOPin.GPIO_P1_05, Enums.FSelect.ALT0); /* SCL */

                // Read the clock divider register
                cdiv = (ushort)peri_read(paddr);
                // Calculate time for transmitting one byte
                // 1000000 = micros seconds in a second
                // 9 = Clocks per byte : 8 bits + ACK
                Variables.i2c_byte_wait_us = (int)(((float)cdiv / Cons.BCM2835_CORE_CLK_HZ) * 1000000 * 9);

                return 1;
            }

            public static void i2c_end()
            {
                // Set all the I2C/BSC1 pins back to input 
                gpio_set_fsel(GPIOPin.RPiGPIOPin.GPIO_P1_03, Enums.FSelect.INPT); // SDA
                gpio_set_fsel(GPIOPin.RPiGPIOPin.GPIO_P1_05, Enums.FSelect.INPT); // SCL
            }

            public static void i2c_setSlaveAddress(byte addr)
            {
                // Set I2C Device Address
                uint* paddr = Variables.bcm2835_bsc1 + Cons.BCM2835_BSC_A / 4;
                peri_write(paddr, addr);
            }

            // defaults to 0x5dc, should result in a 166.666 kHz I2C clock frequency.
            // The divisor must be a power of 2. Odd numbers rounded down.
            public static void i2c_setClockDivider(I2CClockDivider divider)
            {
                uint* paddr = Variables.bcm2835_bsc1 + Cons.BCM2835_BSC_DIV / 4;
                peri_write(paddr, (ushort)divider);
                // Calculate time for transmitting one byte
                // 1000000 = micros seconds in a second
                // 9 = Clocks per byte : 8 bits + ACK
                Variables.i2c_byte_wait_us = (int)(((float)divider / Cons.BCM2835_CORE_CLK_HZ) * 1000000 * 9);
            }

            // set I2C clock divider by means of a baudrate number
            public static void i2c_set_baudrate(uint baudrate)
            {
                uint divider;
                // use 0xFFFE mask to limit a max value and round down any odd number
                divider = (Cons.BCM2835_CORE_CLK_HZ / baudrate) & 0xFFFE;
                i2c_setClockDivider((I2CClockDivider)divider);
            }

            // Writes an number of bytes to I2C
            public static I2CReasonCodes i2c_write(char* buf, uint len)
            {
                uint* dlen = Variables.bcm2835_bsc1 + Cons.BCM2835_BSC_DLEN / 4;
                uint* fifo = Variables.bcm2835_bsc1 + Cons.BCM2835_BSC_FIFO / 4;
                uint* status = Variables.bcm2835_bsc1 + Cons.BCM2835_BSC_S / 4;
                uint* control = Variables.bcm2835_bsc1 + Cons.BCM2835_BSC_C / 4;

                uint remaining = len;
                uint i = 0;
                I2CReasonCodes reason = Enums.I2CReasonCodes.I2C_REASON_OK;

                // Clear FIFO
                peri_set_bits(control, Cons.BCM2835_BSC_C_CLEAR_1, Cons.BCM2835_BSC_C_CLEAR_1);
                // Clear Status
                peri_write(status, Cons.BCM2835_BSC_S_CLKT | Cons.BCM2835_BSC_S_ERR | Cons.BCM2835_BSC_S_DONE);
                // Set Data Length
                peri_write(dlen, len);
                // pre populate FIFO with max buffer
                while (Convert.ToBoolean(remaining) && (i < Cons.BCM2835_BSC_FIFO_SIZE))
                {
                    peri_write_nb(fifo, buf[i]);
                    i++;
                    remaining--;
                }

                // Enable device and start transfer
                peri_write(control, Cons.BCM2835_BSC_C_I2CEN | Cons.BCM2835_BSC_C_ST);

                // Transfer is over when BCM2835_BSC_S_DONE
                while (!Convert.ToBoolean((peri_read(status) & Cons.BCM2835_BSC_S_DONE)))
                {
                    while (Convert.ToBoolean(remaining) && Convert.ToBoolean((peri_read(status) & Cons.BCM2835_BSC_S_TXD)))
                    {
                        // Write to FIFO
                        peri_write(fifo, buf[i]);
                        i++;
                        remaining--;
                    }
                }

                // Received a NACK
                if (Convert.ToBoolean(peri_read(status) & Cons.BCM2835_BSC_S_ERR))
                {
                    reason = Enums.I2CReasonCodes.I2C_REASON_ERROR_NACK;
                }

                // Received Clock Stretch Timeout
                else if (Convert.ToBoolean(peri_read(status) & Cons.BCM2835_BSC_S_CLKT))
                {
                    reason = Enums.I2CReasonCodes.I2C_REASON_ERROR_CLKT;
                }

                // Not all data is sent
                else if (Convert.ToBoolean(remaining))
                {
                    reason = Enums.I2CReasonCodes.I2C_REASON_ERROR_DATA;
                }

                peri_set_bits(control, Cons.BCM2835_BSC_S_DONE, Cons.BCM2835_BSC_S_DONE);

                return reason;
            }

            // Read an number of bytes from I2C
            public static I2CReasonCodes i2c_read(char* buf, uint len)
            {
                uint* dlen = Variables.bcm2835_bsc1 + Cons.BCM2835_BSC_DLEN / 4;
                uint* fifo = Variables.bcm2835_bsc1 + Cons.BCM2835_BSC_FIFO / 4;
                uint* status = Variables.bcm2835_bsc1 + Cons.BCM2835_BSC_S / 4;
                uint* control = Variables.bcm2835_bsc1 + Cons.BCM2835_BSC_C / 4;

                uint remaining = len;
                uint i = 0;
                I2CReasonCodes reason = Enums.I2CReasonCodes.I2C_REASON_OK;

                // Clear FIFO 
                peri_set_bits(control, Cons.BCM2835_BSC_C_CLEAR_1, Cons.BCM2835_BSC_C_CLEAR_1);
                // Clear Status 
                peri_write_nb(status, Cons.BCM2835_BSC_S_CLKT | Cons.BCM2835_BSC_S_ERR | Cons.BCM2835_BSC_S_DONE);
                // Set Data Length 
                peri_write_nb(dlen, len);
                // Start read 
                peri_write_nb(control, Cons.BCM2835_BSC_C_I2CEN | Cons.BCM2835_BSC_C_ST | Cons.BCM2835_BSC_C_READ);

                // wait for transfer to complete 
                while (!Convert.ToBoolean((peri_read_nb(status) & Cons.BCM2835_BSC_S_DONE)))
                {
                    // we must empty the FIFO as it is populated and not use any delay 
                    while (Convert.ToBoolean(peri_read_nb(status) & Cons.BCM2835_BSC_S_RXD))
                    {
                        // Read from FIFO, no barrier 
                        buf[i] = Convert.ToChar(peri_read_nb(fifo));
                        i++;
                        remaining--;
                    }
                }

                // transfer has finished - grab any remaining stuff in FIFO 
                while (Convert.ToBoolean(remaining) && Convert.ToBoolean((peri_read_nb(status) & Cons.BCM2835_BSC_S_RXD)))
                {
                    // Read from FIFO, no barrier 
                    buf[i] = Convert.ToChar(peri_read_nb(fifo));
                    i++;
                    remaining--;
                }

                // Received a NACK 
                if (Convert.ToBoolean(peri_read(status) & Cons.BCM2835_BSC_S_ERR))
                {
                    reason = Enums.I2CReasonCodes.I2C_REASON_ERROR_NACK;
                }

                // Received Clock Stretch Timeout 
                else if (Convert.ToBoolean(peri_read(status) & Cons.BCM2835_BSC_S_CLKT))
                {
                    reason = Enums.I2CReasonCodes.I2C_REASON_ERROR_CLKT;
                }

                // Not all data is received 
                else if (Convert.ToBoolean(remaining))
                {
                    reason = Enums.I2CReasonCodes.I2C_REASON_ERROR_DATA;
                }

                peri_set_bits(control, Cons.BCM2835_BSC_S_DONE, Cons.BCM2835_BSC_S_DONE);

                return reason;
            }
        }

        /*public unsafe static class SPI
        {
        }

        public unsafe static class PWM
        {
        }*/
    }
}
 