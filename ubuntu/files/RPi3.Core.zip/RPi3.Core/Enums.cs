namespace RPi3.Core
{
    public class GPIOPin : Enums
    {
        public enum State : byte
        {
            HIGH = Cons_State.HIGH,
            LOW = Cons_State.LOW
        }
    }
    
    public class Enums
    {
        public enum FSelect : byte
        {
            INPT = 0x00,   /*!< Input 0b000 */
            OUTP = 0x01,   /*!< Output 0b001 */
            ALT0 = 0x04,   /*!< Alternate function 0 0b100 */
            ALT1 = 0x05,   /*!< Alternate function 1 0b101 */
            ALT2 = 0x06,   /*!< Alternate function 2 0b110, */
            ALT3 = 0x07,   /*!< Alternate function 3 0b111 */
            ALT4 = 0x03,   /*!< Alternate function 4 0b011 */
            ALT5 = 0x02,   /*!< Alternate function 5 0b010 */
            MASK = 0x07    /*!< Function select bits mask 0b111 */
        }

        public enum PUDControl
        {
            GPIO_PUD_OFF = 0x00,   /*!< Off ? disable pull-up/down 0b00 */
            GPIO_PUD_DOWN = 0x01,   /*!< Enable Pull Down control 0b01 */
            GPIO_PUD_UP = 0x02    /*!< Enable Pull Up control 0b10  */
        }

        public enum RPiGPIOPin : byte
        {
            #region RPI3
                // RPi Version 2 */
                GPIO_P1_03 = 2,  /*!< Version 2, Pin P1-03 */
                GPIO_P1_05 = 3,  /*!< Version 2, Pin P1-05 */
                GPIO_P1_07 = 4,  /*!< Version 2, Pin P1-07 */
                GPIO_P1_08 = 14,  /*!< Version 2, Pin P1-08, defaults to alt function 0 UART0_TXD */
                GPIO_P1_10 = 15,  /*!< Version 2, Pin P1-10, defaults to alt function 0 UART0_RXD */
                GPIO_P1_11 = 17,  /*!< Version 2, Pin P1-11 */
                GPIO_P1_12 = 18,  /*!< Version 2, Pin P1-12, can be PWM channel 0 in ALT FUN 5 */
                GPIO_P1_13 = 27,  /*!< Version 2, Pin P1-13 */
                GPIO_P1_15 = 22,  /*!< Version 2, Pin P1-15 */
                GPIO_P1_16 = 23,  /*!< Version 2, Pin P1-16 */
                GPIO_P1_18 = 24,  /*!< Version 2, Pin P1-18 */
                GPIO_P1_19 = 10,  /*!< Version 2, Pin P1-19, MOSI when SPI0 in use */
                GPIO_P1_21 = 9,  /*!< Version 2, Pin P1-21, MISO when SPI0 in use */
                GPIO_P1_22 = 25,  /*!< Version 2, Pin P1-22 */
                GPIO_P1_23 = 11,  /*!< Version 2, Pin P1-23, CLK when SPI0 in use */
                GPIO_P1_24 = 8,  /*!< Version 2, Pin P1-24, CE0 when SPI0 in use */
                GPIO_P1_26 = 7,  /*!< Version 2, Pin P1-26, CE1 when SPI0 in use */
                GPIO_P1_29 = 5,  /*!< Version 2, Pin P1-29 */
                GPIO_P1_31 = 6,  /*!< Version 2, Pin P1-31 */
                GPIO_P1_32 = 12,  /*!< Version 2, Pin P1-32 */
                GPIO_P1_33 = 13,  /*!< Version 2, Pin P1-33 */
                GPIO_P1_35 = 19,  /*!< Version 2, Pin P1-35 */
                GPIO_P1_36 = 16,  /*!< Version 2, Pin P1-36 */
                GPIO_P1_37 = 26,  /*!< Version 2, Pin P1-37 */
                GPIO_P1_38 = 20,  /*!< Version 2, Pin P1-38 */
                GPIO_P1_40 = 21,  /*!< Version 2, Pin P1-40 */
            #endregion
        }

        public enum I2CClockDivider : ushort
        {
            I2C_CLOCK_DIVIDER_2500 = 2500,      // !< 2500 = 10us = 100 kHz
            I2C_CLOCK_DIVIDER_626 = 626,       // !< 622 = 2.504us = 399.3610 kHz
            I2C_CLOCK_DIVIDER_150 = 150,       // !< 150 = 60ns = 1.666 MHz (default at reset)
            I2C_CLOCK_DIVIDER_148 = 148        // !< 148 = 59ns = 1.689 MHz
        }

        public enum I2CReasonCodes : byte
        {
            I2C_REASON_OK = 0x00,      /*!< Success */
            I2C_REASON_ERROR_NACK = 0x01,      /*!< Received a NACK */
            I2C_REASON_ERROR_CLKT = 0x02,      /*!< Received Clock Stretch Timeout */
            I2C_REASON_ERROR_DATA = 0x04       /*!< Not all data is sent / received */
        }
    }
}