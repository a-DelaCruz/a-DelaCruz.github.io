namespace RPi3.Core
{
    public static class Cons_State
    {
        public const uint MAP_FAILED = 0xFFFFFFFF;
        public const byte HIGH = 0x1;
        public const byte LOW = 0x0;
    }
}