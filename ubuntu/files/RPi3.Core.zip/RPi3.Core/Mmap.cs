using System;
using static RPi3.Core.Interop.Enums;

namespace RPi3.Core
{
    internal unsafe static class Mmap
    {
        internal static void* mapmem(uint size, int fd, uint off)
        {
            IntPtr map = Interop.Interop.mmap(IntPtr.Zero, size, MmapProts.PROT_READWRITE, MmapFlags.MAP_SHARED, fd, off);
            if ((uint)map == Cons_State.MAP_FAILED)
                Console.WriteLine("mmap failed: {0}", map);
            //Console.WriteLine("mmap failed test output: {0}" ,(uint)map);
            return map.ToPointer();//2952667136
        }
        internal static void unmapmem(ref uint* pmem, uint size)
        {
            if (pmem == (uint*)Cons_State.MAP_FAILED) return;
            Interop.Interop.munmap(new IntPtr(pmem), size);
            pmem = (uint*)Cons_State.MAP_FAILED;
        }
    }
}