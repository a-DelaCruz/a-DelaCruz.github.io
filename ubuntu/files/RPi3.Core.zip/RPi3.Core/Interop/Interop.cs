using System;
using System.Runtime.InteropServices;
using static RPi3.Core.Interop.Enums;

namespace RPi3.Core.Interop
{
    internal static class Interop
    {

        [DllImport("libc.so.6")]
        public static extern int geteuid();

        [DllImport("libc.so.6")]
        public static extern int open(string pathname, OpenFlags flags);

        [DllImport("libc.so.6")]
        public static extern int close(int fd);

        [DllImport("libc.so.6")]
        public static extern void sync();

        [DllImport("libc.so.6")]
        public static extern IntPtr mmap(IntPtr addr, uint length, MmapProts prot, MmapFlags flags, int fd, uint offset);

        [DllImport("libc.so.6")]
        public static extern int munmap(IntPtr addr, uint length);

        [DllImport("libc.so.6")]
        public static extern int nanosleep(ref timespec req, ref timespec rem);
    }
}