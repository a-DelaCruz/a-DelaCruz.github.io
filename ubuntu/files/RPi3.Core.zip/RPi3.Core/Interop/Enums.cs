using System;

namespace RPi3.Core.Interop
{
    public static class Enums
    {
        public enum OpenFlags : int // Open
        {
            O_RDWR = 2,
            O_SYNC = 10000
        }


        public enum MmapProts : int //mmap
        {
            PROT_READ = 1,  // Page can be read.
            PROT_WRITE = 2,  // Page can be written.
            PROT_EXEC = 4,  // Page can be executed.
            PROT_READWRITE = PROT_READ | PROT_WRITE
        }


        public enum MmapFlags : int // mmap
        {
            MAP_SHARED = 1,     // Share changes.
            MAP_PRIVATE = 2     // Changes are private.
        }

        public struct timespec  //Delay
        {
            public IntPtr tv_sec; /* seconds */
            public IntPtr tv_nsec; /* nanoseconds */
        }
    }
}